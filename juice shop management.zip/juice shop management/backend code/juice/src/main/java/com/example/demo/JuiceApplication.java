package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JuiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(JuiceApplication.class, args);
	}

}
